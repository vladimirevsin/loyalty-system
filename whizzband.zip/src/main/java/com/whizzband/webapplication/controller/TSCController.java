package com.whizzband.webapplication.controller;

import com.whizzband.webapplication.setting.NodeRPCConnection;
import net.corda.core.messaging.CordaRPCOps;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class TSCController {
    private final CordaRPCOps proxy;

    @Bean
    public CordaRPCOps getProxy() {
        return proxy;
    }

    public TSCController(NodeRPCConnection nodeRPCConnection) {
        this.proxy = nodeRPCConnection.getProxy();
    }
}
