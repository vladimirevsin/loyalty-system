package com.whizzband.webapplication.model

import enums.EnumError

data class ResultData(val code: Int = -1, val message: String = "") {
    constructor(enumError: EnumError) : this(enumError.code, enumError.message)
}