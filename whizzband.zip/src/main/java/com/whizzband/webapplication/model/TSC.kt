package com.whizzband.webapplication.model

import net.corda.core.identity.CordaX500Name

data class TSC(val name: String,
               val address: String,
               val login: String,
               val password: String,
               val nameInCorda: CordaX500Name)