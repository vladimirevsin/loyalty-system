package com.whizzband.webapplication.model

data class Abonent(val FIO: String,
                   val phoneNumber: String,
                   val password: String,
                   val identificator: Int)