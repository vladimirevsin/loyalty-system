package com.template.whitelist;

import net.corda.core.serialization.SerializationWhitelist;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class WhizzbandSerializationWhitelist implements SerializationWhitelist {

    @NotNull
    @Override
    public List<Class<?>> getWhitelist() {
        return Arrays.asList(
                List.class
        );

    }
}
